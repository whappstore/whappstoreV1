#!/bin/bash
# Grep User V1
# Author: Boranity

# Colors
white="\033[1;37m"
grey="\033[0;37m"
purple="\033[0;35m"
red="\033[1;31m"
green="\033[1;32m"
yellow="\033[1;33m"
purple="\033[0;35m"
cyan="\033[0;36m"
cafe="\033[0;33m"
fiuscha="\033[0;35m"
blue="\033[1;34m"
tp="\e[0m"
clear

trap ctrl_c INT
ctrl_c() {
echo -e "\n"
echo -e "[${red}${yellow}*${red}]$green Thanks For Use Grep User$tp"
exit 0
}

if [[ $USER = "root" ]] ; then 
echo "ok" &> /dev/null
else 
echo -ne "${red}sudo bash grep-user.sh \n"
sleep 1     
exit
fi

if [[ $(command -v curl) != "" ]] ; then
    echo "ok" &> /dev/null
else 
    echo "Download Curl"
    apt install curl &> /dev/null
    eopkg install curl &> /dev/null
    pacman -S curl &> /dev/null
    pisi it curl &> /dev/null
    dnf install curl &> /dev/null
    echo "OK"
    sleep 1 
    clear 
fi

if [[ $(command -v grep) != "" ]] ; then
    echo "ok" &> /dev/null
else 
    echo "Download Grep"
    apt install grep &> /dev/null
    eopkg install grep &> /dev/null
    pacman -S grep &> /dev/null
    pisi it grep &> /dev/null
    dnf install grep &> /dev/null
    echo "OK"
    sleep 1 
    clear 
fi

echo -e """ 

$green  ██████╗ ██████╗ ███████╗██████╗     ██╗   ██╗███████╗███████╗██████╗ 
$blue ██╔════╝ ██╔══██╗██╔════╝██╔══██╗    ██║   ██║██╔════╝██╔════╝██╔══██╗
$cafe ██║  ███╗██████╔╝█████╗  ██████╔╝    ██║   ██║███████╗█████╗  ██████╔╝
$white ██║   ██║██╔══██╗██╔══╝  ██╔═══╝     ██║   ██║╚════██║██╔══╝  ██╔══██╗
$red ╚██████╔╝██║  ██║███████╗██║         ╚██████╔╝███████║███████╗██║  ██║
$purple  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝          ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝
$cyan                                                            Author: Boranity
$blue                                                            Version: V1
"""
echo ""
echo -ne "${red}Enter Username: " ; read username

# Facebook

facebook=$(curl -s "https://www.facebook.com/$username" -L -H "Accept-Language: en" | grep -o 'not found'; echo $?)
if [[ $facebook == *'1'* ]]; then
printf " ${blue}[${purple}*${blue}]${green}Found! ${yellow}https://www.facebook.com/%s\n $tp" $username
elif [[ $facebook == *'0'* ]]; then
printf " ${blue}[${purple}*${blue}]${red}Not Found! ${yellow}https://www.facebook.com/%s\n $tp" $username
fi

# Github

github=$(curl -s "https://www.github.com/$username" -L -H "Accept-Language: en" | grep -o 'Repositories'; echo $?)
if [[ $github == *'0'* ]]; then
printf "${blue}[${purple}*${blue}]${green}Found! ${yellow}https://www.github.com/%s\n $tp" $username
elif [[ $github == *'1'* ]]; then
printf "${blue}[${purple}*${blue}]${red}Not Found! ${yellow}https://www.github.com/%s\n $tp" $username
fi

# Youtube

youtube=$(curl -s "https://www.youtube.com/$username" -L -H "Accept-Language: en" | grep -o 'Not Found'; echo $?)
if [[ $youtube == *'1'* ]]; then
printf "${blue}[${purple}*${blue}]${green}Found! ${yellow}https://www.youtube.com/%s\n $tp" $username
elif [[ $youtube == *'0'* ]]; then
printf "${blue}[${purple}*${blue}]${red}Not Found! ${yellow}https://www.youtube.com/%s\n $tp" $username
fi

# İnstagram (GitHub says that the reason I write is because Instagram blocks it, so it can't be found)

instagram=$(curl -s "https://instagram.com/$username" -L -H "Accept-Language: en" | grep -o 'The'; echo $?)
if [[ $instagram == *'0'* ]]; then
printf " ${blue}[${purple}*${blue}]${green}Found! ${yellow}https://www.instagram.com/%s\n $tp" $username
elif [[ $instagram == *'1'* ]]; then
printf " ${blue}[${purple}*${blue}]${red}Not Found! ${yellow}https://www.instagram.com/%s\n $tp" $username
fi

# Spotify
