#!/bin/bash

for i in $( eval echo {0..$(wc -w  $1 | awk '{print $1}')}) ; do
	 echo -en "\"$(cat "$1" | awk "NR==${i}")\" "
done
