#!/bin/bash

#    White Panther Tool a GUI Mutli Tool Kit for GNU/Linux White Hat PNM OS Project
#    Copyright (C) 2021  suleymanfatihşimşek&lazypwny
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>

setversion="1.0"
setroot="/usr/share/whappstore"
author="Süleyman Fatih Şimşek"

if [ -e ${setroot}/lang.conf ] ; then
    source ${setroot}/lang.conf
else
    echo "lang='$LANGUAGE'" > ${setroot}/lang.conf
    source ${setroot}/lang.conf
fi

## args

case ${1} in
    [sS][eE][tT][lL][aA][nN][gG]|--[sS][eE][tT][lL][aA][nN][gG]|-[sS][lL])
        lang=""
        echo -e "\n\ttr_TR\tfr_FR\tgr_GR\ten_EN"
        read -p "   please type your langauge correctly[en_EN]:> " lang
    ;;
esac

##

case $lang in
    tr_TR)
        errors=("Bilinmeyen Bir Hata Oluştu" "Bilinmeyen Seçenek" "Bu Seçenek Henüz Hazır Değil")
        dialogs=("WhappStore ${setversion} sürümüne Hoş Geldiniz" "Lütfen Yukardaki Kategorilerden Birini Seçiniz" "Bizi Seçtiğiniz İçin Teşekkür Ederiz." "Herdaim Sizin İçin En İyisini Yapmaya Çalışıyoruz." "Discord Sunucumuza Gelerek Topluluğumuzun Gelişmesine Yardımcı Olabilirsin: https://discord.gg/xGnc9WRXv4" "PNM OS'un Maskotu Kareteci Penguendir.")
    ;;
    fr_FR)
        errors=("Erreur inconnue" "L'Option Est Inconnue" "Cette option n'est pas encore prête.")
        dialogs=("Bienvenue de WhappStore ${setversion}" "Svp Selecte Une Categorie." "Merci de nous avoir choisi" "Nous essayons toujours de faire le meilleur pour vous." "Vous pouvez aider notre communauté à grandir en visitant notre serveur Discord: https://discord.gg/xGnc9WRXv4" "La mascotte de PNM OS est le pingouin marqueur.")
    ;;
    gr_GR)
        errors=("Unbekannter Fehler" "Unbekannte Option" "Diese Option ist noch nicht fertig")
        dialogs=("Willkommen im WhappStore ${setversion}" "Bitte wählen Sie eine Kategorie" "Danke, daß Sie uns gewählt haben." "Wir versuchen immer, das Beste für Sie zu tun." "Sie können unserer Community zum Wachstum verhelfen, indem Sie unseren Discord Server besuchen: https://discord.gg/xGnc9WRXv4" "Das Maskottchen von PNM OS ist der Scorer Penguin.")
    ;;
    *)
        errors=("Unknow Error" "Unknow Option" "This Option isn't Yet Ready")
        dialogs=("Welcome to WhappStore ${setversion}" "Please Choise Any Category" "Thank you for choosing us." "Always We Are Trying To Do The Best For You." "You can help our community grow by visiting our Discord Server: https://discord.gg/xGnc9WRXv4" "The Mascot of PNM OS is the Scorer Penguin.")  
    ;;
esac